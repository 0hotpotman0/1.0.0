
#ifndef __STM32_H__
#define __STM32_H__

#include "STM32F0xx\Include\stm32f0xx.h"

#endif /* __STM32_H__ */
