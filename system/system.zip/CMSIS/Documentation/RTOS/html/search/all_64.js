var searchData=
[
  ['def',['def',['../group___c_m_s_i_s___r_t_o_s___definitions.html#a596b6d55c3321db19239256bbe403df6',1,'osEvent']]],
  ['dummy',['dummy',['../structos_mutex_def__t.html#a44b7a3baf02bac7ad707e8f2f5eca1ca',1,'osMutexDef_t::dummy()'],['../structos_semaphore_def__t.html#a44b7a3baf02bac7ad707e8f2f5eca1ca',1,'osSemaphoreDef_t::dummy()']]]
];
