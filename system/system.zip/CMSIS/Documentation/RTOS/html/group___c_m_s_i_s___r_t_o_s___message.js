var group___c_m_s_i_s___r_t_o_s___message =
[
    [ "osFeature_MessageQ", "group___c_m_s_i_s___r_t_o_s___message.html#ga479a6561f859e3d4818e25708593d203", null ],
    [ "osMessageQ", "group___c_m_s_i_s___r_t_o_s___message.html#ga2d446a0b4bb90bf05d6f92eedeaabc97", null ],
    [ "osMessageQDef", "group___c_m_s_i_s___r_t_o_s___message.html#gac9a6a6276c12609793e7701afcc82326", null ],
    [ "osMessageCreate", "group___c_m_s_i_s___r_t_o_s___message.html#gaf3b9345cf426304d46565152bc26fb78", null ],
    [ "osMessageGet", "group___c_m_s_i_s___r_t_o_s___message.html#ga6c6892b8f2296cca6becd57ca2d7e1ae", null ],
    [ "osMessagePut", "group___c_m_s_i_s___r_t_o_s___message.html#gac0dcf462fc92de8ffaba6cc004514a6d", null ]
];