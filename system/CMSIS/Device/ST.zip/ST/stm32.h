
#ifndef __STM32_H__
#define __STM32_H__

#include "STM32F0xx\Include\MM32F031x4x6_q.h"

#endif /* __STM32_H__ */
